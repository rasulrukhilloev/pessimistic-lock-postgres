export const TYPES = {
  RedisClient: Symbol.for('RedisClient'),
};