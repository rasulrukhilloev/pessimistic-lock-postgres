import { injectable } from 'inversify';
import { DataSource, Repository, LessThan } from 'typeorm';
import { EndpointEntity as Endpoint } from '../entities/endpoint.entity';

@injectable()
export class EndpointRepository {
  private repository: Repository<Endpoint>;

  constructor(private dataSource: DataSource) {
    this.repository = this.dataSource.getRepository(Endpoint);
  }

  async setValue(userId: string, value: number, expiresAt: Date): Promise<Endpoint> {
    const existingEndpoint = await this.repository.findOne({ where: { user: { id: userId } } });
    if (existingEndpoint) {
      existingEndpoint.value = value;
      existingEndpoint.expires_at = expiresAt;
      return this.repository.save(existingEndpoint);
    } else {
      const endpoint = this.repository.create({ user: { id: userId }, value, expires_at: expiresAt });
      return this.repository.save(endpoint);
    }
  }

  async getValue(userId: string): Promise<Endpoint | null> {
    return this.repository.findOne({ where: { user: { id: userId } } });
  }

  async deleteValue(userId: string): Promise<void> {
    await this.repository.delete({ user: { id: userId } });
  }

  async getExpiredEndpoints(): Promise<Endpoint[]> {
    return this.repository.find({
      where: { expires_at: LessThan(new Date()) },
      relations: ['user']
    });
  }
}